package com.restapi.contactsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(ContactSystemApplication.class, args);
    }

}
