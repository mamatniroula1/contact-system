package com.restapi.contactsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
